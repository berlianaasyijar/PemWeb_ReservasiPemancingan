export const firebaseConfig = {
    apiKey: "AIzaSyAxEob-ennGa8FdHCEUroxRBeRDJhGg0mg",
    authDomain: "projectpemancinganpemweb.firebaseapp.com",
    databaseURL: "https://projectpemancinganpemweb-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "projectpemancinganpemweb",
    storageBucket: "projectpemancinganpemweb.appspot.com",
    messagingSenderId: "569015410790",
    appId: "1:569015410790:web:a64c7daa753f8ba7e34da7",
    measurementId: "G-585C6YSL87"
};